package br.com.xone.test;

import static ch.lambdaj.Lambda.*;
import static java.util.Arrays.asList;

import java.util.List;

import br.com.xone.model.Person;

/**
 * Feb 13, 2012
 * @author fabio
 *
 */
public class ForEachTest {
	
	public static void main(final String[] args) {
		List<Person> people = asList(new Person("Fabio"), new Person("Masson"), new Person("x1"));
		
		forEach(people).setId(50L);
		
		for(Person p : people) {
			System.out.println("id: " + p.getId() + " name: " + p.getName());
		}
		
	}

}
