package br.com.xone.test;

import static java.util.Arrays.asList;
import static ch.lambdaj.Lambda.*;
import static org.hamcrest.Matchers.*;

import java.util.List;

import br.com.xone.model.Person;

/**
 * Feb 13, 2012
 * @author fabio
 *
 */
public class ExtractTest {
	
	public static void main(final String[] args) {
		List<Person> people = asList(new Person("Fabio"), new Person("Masson"), new Person("x1"));
		
		forEach(people).setAge(27);
		
		List<Integer> ages = extract(people, on(Person.class).getAge());
		
		for(Integer age: ages){
			System.out.println("age: " + age);
		}
		
		
	}

}
