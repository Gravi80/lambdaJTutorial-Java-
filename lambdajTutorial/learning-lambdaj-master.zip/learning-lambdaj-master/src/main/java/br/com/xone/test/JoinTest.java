package br.com.xone.test;

import static ch.lambdaj.Lambda.*;
import static java.util.Arrays.asList;

import java.util.List;

import br.com.xone.model.Person;

/**
 * Feb 13, 2012
 * @author fabio
 *
 */
public class JoinTest {
	
	public static void main(final String[] args) {
		List<String> partsName = asList("Fabio", "Cesar", "Masson");
		String completeName = join(partsName, " - ");
		
		System.out.println(completeName);
		
		List<Person> people = asList(new Person("Fabio_1"), new Person("Fabio_2"), new Person("x1"));

		
		String names = joinFrom(people).getName();
		
		System.out.println("names: " + names);
	}

}
