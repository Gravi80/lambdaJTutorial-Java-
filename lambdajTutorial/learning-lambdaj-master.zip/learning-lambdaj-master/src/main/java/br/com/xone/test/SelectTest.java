package br.com.xone.test;

import static java.util.Arrays.asList;
import static ch.lambdaj.Lambda.*;
import static org.hamcrest.Matchers.*;

import java.util.List;

import br.com.xone.model.Person;

/**
 * Feb 13, 2012
 * @author fabio
 *
 */
public class SelectTest {
	
	public static void main(final String[] args) {
		List<Person> people = asList(new Person("X1"), new Person("Masson"), new Person("Fabio"));
		
		List<Person> peopleWithNameFabio = select(people, having(on(Person.class).getName(), equalTo("Fabio")));		
		
		System.out.println("size: " + peopleWithNameFabio.size());
	}

}
