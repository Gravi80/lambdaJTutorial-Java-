package br.com.xone.test;

import static java.util.Arrays.asList;
import static ch.lambdaj.Lambda.*;

import java.util.List;

import br.com.xone.model.Person;

/**
 * Feb 13, 2012
 * @author fabio
 *
 */
public class SortTest {
	
	public static void main(final String[] args) {
		List<Person> people = asList(new Person("X1"), new Person("Masson"), new Person("Fabio"));
		
		List<Person> sortedPeople = sort(people, on(Person.class).getName());
		
		for(Person p: sortedPeople){
			System.out.println("name: " + p.getName());
		}
		
	}

}
