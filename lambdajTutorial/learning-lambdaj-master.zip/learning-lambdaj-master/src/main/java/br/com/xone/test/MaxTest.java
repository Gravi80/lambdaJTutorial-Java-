package br.com.xone.test;

import static java.util.Arrays.asList;
import static ch.lambdaj.Lambda.*;

import java.util.List;

import br.com.xone.model.Person;

/**
 * Feb 13, 2012
 * @author fabio
 *
 */
public class MaxTest {
	
	public static void main(final String[] args) {
		List<Person> people = asList(new Person("Fabio"), new Person("Masson"), new Person("x1"));
		
		forEach(people).setAge(28);
		
		people.get(0).setAge(50);
		
		Integer maxAge = max(people, on(Person.class).getAge());
		
		System.out.println("max age: " + maxAge);
		
		
	}

}
